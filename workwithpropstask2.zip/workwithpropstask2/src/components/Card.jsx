function Card(props){
  return(
      <div className="Card">
      <h1>
        {props.itemTitle}
    </h1>
    <p>
        {props.isInStock ? "In stock" : "Out of stock"}
    </p>
    <h4>
        {props.itemPrice}$
    </h4>
</div>
);
}

export default Card;