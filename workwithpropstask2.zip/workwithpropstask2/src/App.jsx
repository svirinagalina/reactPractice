import Card from './components/Card.jsx'


function App() {
    return (
        <div className="App">
            <Card itemTitle="Milk" isInStock={true} itemPrice="5"/>
            <Card itemTitle="Bread" isInStock={false} itemPrice="2"/>
            <Card itemTitle="Meat" isInStock={true} itemPrice="10"/>

        </div>

    );
}

export default App;
