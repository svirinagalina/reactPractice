
import ToDoItem from "./components/ToDoItem.jsx";


function App() {

    return (
        <div className="App">
        <ToDoItem text="Выучить React" isCompleted={true}>
        </ToDoItem>
        </div>
    )
}

export default App
