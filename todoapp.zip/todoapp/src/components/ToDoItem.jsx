function ToDoItem({text, isCompleted}) {
    return(
        <div className="toDoItem">
        <h4>
            {isCompleted ? "Cделано" : "Не сделано"}
        </h4>
    <p>{text}</p>
        </div>
);
}

ToDoItem.defaultProps = {
            text: "Новая задача",
                isCompleted: false

}
export default ToDoItem;