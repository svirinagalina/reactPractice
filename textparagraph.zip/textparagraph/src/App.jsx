function App() {
    const divStyle = {
        background: 'lightblue',
        border: '2px solid blue',
        height: 125,
        width: 450,
    };
    const pStyle ={
        color: 'purple',
    };
    return (
        <div style={divStyle}>
            <p style={pStyle}>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.<br />
                Sed pellentesque purus et vehicula condimentum. Cras et dictum elit.<br
            />
                Nullam vitae mi ultrices, pretium ante sed, semper felis.<br />
                Mauris ultricies dignissim lectus sit amet cursus.<br />
                Aliquam vitae orci at arcu eleifend ullamcorper vitae eget dolor.
            </p>
        </div>
    );
}
export default App;