import React, {useState} from 'react';

function App() {
const [count, setCount] = useState(0);

return (
    <div className="App">
        <p>
            Вы кликнули {count} раз
        </p>
        <button onClick={()=> setCount(count +1)}> Нажми меня </button>
    </div>
);
}

export default App;
