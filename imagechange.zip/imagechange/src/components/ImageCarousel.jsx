import { useState } from 'react';

function ImageCarousel() {
    const imgUrls = [
        'https://mykaleidoscope.ru/x/uploads/posts/2022-10/1666206233_68-mykaleidoscope-ru-p-kartinka-na-zastavku-oboi-69.jpg',
        'https://vip-1gl.ru/vipberrrt/10423beautiful_scenery_wallpaper.jpg',
        'https://www.superiorwallpapers.com/water/wonderful-landscape-nature-mountain-river_5120x3200.jpg'
    ];

    const [currentImageIndex, setCurrentImageIndex] = useState(0);

    const handleClick = () => {
        setCurrentImageIndex(
            (prevIndex) => (prevIndex + 1) % imgUrls.length
        );
    };

    return (
        <div style={{ display: 'flex', flexDirection: 'column' }}>
            <img
                src={imgUrls[currentImageIndex]}
                alt="Изображение карусели"
                style={{
                    width: '800px',
                    height: '500px',
                    objectFit: 'cover'
                }}
            />

            <button
                onClick={handleClick}
                style={{
                    border: '1px solid green',
                    borderRadius: '10px',
                    height: '70px',
                    width: '200px'
                }}
            >
                Следующее изображение
            </button>
        </div>
    );
}

export default ImageCarousel;