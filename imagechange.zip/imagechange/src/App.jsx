import ImageCarousel from './components/ImageCarousel.jsx';

function App() {
    return (
        <div>
            <ImageCarousel />
        </div>
    );
}

export default App;