

import {useState} from "react";
import Animals from "./components/Animals";



function App() {
return (<div>
    <Animals/>
</div>
);
}

export default App;
