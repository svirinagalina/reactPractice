import {useState} from "react";

const animalList = [
    'Собака',
    'Кошка',
    'Заяц',
    'Волк',
    'Лиса',
    'Медведь',
    'Олень',
    'Сурок',
    'Хомяк',
    'Белка'
];

function Animals() {
    const [animals, setAnimals] = useState([]);

    const updateAnimals = animal => {
        setAnimals(prevAnimals => [...prevAnimals, animal]);
    };

    function reandomAnimal() {

        const randomInt = Math.floor(Math.random() * 10);
        updateAnimals(animalList[randomInt]);
    }

    return (
        <div>
            <button onClick={reandomAnimal}>
                Добавить случайное животное
            </button>
            <ul>
                {animals.map((animal, index) => (<li key={animal + index}>{animal}</li>
                ))}
            </ul>
        </div>

    );
}

export default Animals;
