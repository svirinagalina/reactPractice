import {useState} from 'react';
import CityCard from "./components/CityCard.jsx";
import CitySelector from "./components/CitySelector.jsx";

function App() {
    const [selectedCity, setSelectedCity] = useState(null);

return(
    <div className="App">
        <h1>City Cards</h1>
        <CitySelector onSelectedCityChange={setSelectedCity} />
        {selectedCity && <CityCard city={selectedCity} />}
    </div>
);

}

export default App;
