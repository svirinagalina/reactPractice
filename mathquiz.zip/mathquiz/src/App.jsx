import MathQuiz from "./components/MathQuiz.jsx";
import "./App.css";

function App() {
return    <div className="app">
<MathQuiz />
    </div>
}

export default App;
