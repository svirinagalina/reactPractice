 import {useState} from "react";
import Answer from"./Answer.jsx";

function MathQuiz() {
    const[points, setPoints] = useState(0);

    const a = Math.floor(Math.random() * 10) + 1;
    const b = Math.floor(Math.random() * 10) +1;

const updatePoints = (isCorrect) => {
    if (isCorrect) {
        setPoints(points +1);
    } else {
        setPoints(points -1);
    }
};
return (
    <div className="quiz"> MathQuiz
    <p className="Score">
        текущий счет: <strong>{points}</strong>
    </p>
    <p className="task"> {a}+{b}=?
    </p>
    <Answer a={a} b={b} updatePoints={updatePoints}/>
    </div>
);
}

export default MathQuiz;