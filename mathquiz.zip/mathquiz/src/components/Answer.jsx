import {useState} from "react";

function Answer({a,b, updatePoints}) {
    const[userAnswer,setUserAnswer] = useState("");

    const handlesubmit= (event) => {
        event.preventDefault();

        const correctAnswer = a+b;
        const isCorrect= Number(userAnswer) == correctAnswer;

        updatePoints(isCorrect);
        setUserAnswer("");
    };

    return(
        <form className="answer-form" onSubmit={handlesubmit}>
            <input
            type="number"
            value={userAnswer}
            onChange={(event)=>setUserAnswer(event.target.value)}
            placeholder="Enter Your Answer"
            required
                />

            <button type="submit">Проверить</button>
        </form>
    );
}

export default Answer;