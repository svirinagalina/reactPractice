import '../Styles/TeamCard.css';

function TeamCard({name, members}) {

    return(
        <div className="TeamCard">
            <h3 className="TeamName">{name}</h3>
            <ul>
                {members.map(member => (
                    <li key={member.id}></li>
                ))}
            </ul>
        </div>
    );
};

export default TeamCard;
