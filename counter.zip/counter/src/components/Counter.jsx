import { useState } from 'react'

function Counter() {
    const[count, setCount] = useState(0)
    const handlecontainerClick = (event) => {
        if (event.target.dataset.action === 'increment') {
            setCount(count + 1);
        } else if (event.target.dataset.action === 'decrement') {
            setCount(prevCount => prevCount - 1);
        }
    };
        return (
            <div onClick={handlecontainerClick}>
            <h2>Счетчик {count}</h2>
            <button data-action="increment">Увеличить</button>
        <button data-action="decrement">Уменьшить</button>
            </div>
        );
}

export default Counter;