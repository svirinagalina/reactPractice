import {useState} from 'react';
function Animals() {
    const[animal, setAnimal] = useState([]);
    const animalList = [
        'Собака',
        'Кошка',
        'Заяц',
        'Волк',
        'Лиса',
        'Медведь',
        'Олень',
        'Сурок',
        'Хомяк',
        'Белка'
    ];

    const updateAnimal = (animal) => {
        setAnimal(prevAnimals => [...prevAnimals, animal]);
    };

    function randomAnimal() {
        const randomIndex = Math.floor(Math.random() * animalList.length);
        updateAnimal(animalList[randomIndex]);
    };

    return (
        <div>
        <button onClick={randomAnimal}> Добавить случайное животное </button>
    <ul>
        {animal.map((animal, index) => (<li key={index}>{animal}</li>))}
    </ul>
        </div>);

}
export default Animals;