
import './App.css'
import AlbumList from "./components/AlbumList.jsx";

function App() {
return(
    <div className="App">
        <AlbumList />
    </div>
);
}

export default App
