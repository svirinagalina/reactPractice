import SearchBar from '../SearchBar/SearchBar.jsx';
import PartnersBar from '../PartnersBar/PartnersBar.jsx';
import CategoryCardList from '../CategoryCardList/CategoryCardList.jsx';
import VacancyList from '../VacancyList/VacancyList.jsx';
import styles from './Main.module.css';

export default function Main() {
  return (
    <main className={styles.main}>
      <SearchBar />
      <PartnersBar />
      <div className={styles.light_bg}>
        <CategoryCardList />
        <VacancyList />
      </div>
    </main>
  );
}
