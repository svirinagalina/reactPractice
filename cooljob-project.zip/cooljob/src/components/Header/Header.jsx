import styles from './Header.module.css';

export default function Header() {
  return (
    <header className={styles.header}>
      <div className={styles.header_left}>
        <a href="/" className={styles.logo}>Cooljob</a>
        <nav className={styles.nav}>
          <a href="#" className={styles.nav_link}>Поиск работы</a>
          <a href="#" className={styles.nav_link}>Поиск стартапов</a>
        </nav>
      </div>
      <div className={styles.header_right}>
        <a href="#" className={styles.register}>Регистрация</a>
        <a href="#" className={styles.login}>Вход</a>
      </div>
    </header>
  );
}
