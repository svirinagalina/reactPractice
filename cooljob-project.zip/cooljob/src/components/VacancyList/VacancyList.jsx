import VacancyCard from '../VacancyCard/VacancyCard.jsx';
import sony from '../../assets/logos/sony.png';
import facebook from '../../assets/logos/facebook.png';
import cocacola from '../../assets/logos/cocacola.png';
import styles from './VacancyList.module.css';

const vacancies = [
  {
    id: 1,
    category: 'Финансы',
    color: '#5B67F6',
    title: 'Менеджер по управлению финансами в крупной компании',
    city: 'Осака, Япония',
    company: 'Sony',
    logo: sony,
    date: '3 дня назад',
  },
  {
    id: 2,
    category: 'Продажи',
    color: '#E95CE9',
    title: 'Специалист по продажам',
    city: 'Коясан, Япония',
    company: 'Facebook',
    logo: facebook,
    date: '7 дней назад',
  },
  {
    id: 3,
    category: 'Служба поддержки',
    color: '#59C85A',
    title: 'Оператор колл центра',
    city: 'Томаму, Япония',
    company: 'CocaCola',
    logo: cocacola,
    date: '1 день назад',
  },
  {
    id: 4,
    category: 'Мультимедиа',
    color: '#F79552',
    title: 'Системный администратор',
    city: 'Токио, Япония',
    company: 'Sony',
    logo: sony,
    date: '3 дня назад',
  },
  {
    id: 5,
    category: 'Дизайн',
    color: '#EF4A4A',
    title: 'Дизайнер интерьера в профессиональную студию в центре города',
    city: 'Йокогама, Япония',
    company: 'Facebook',
    logo: facebook,
    date: '7 дней назад',
  },
  {
    id: 6,
    category: 'Грузоперевозки',
    color: '#2B2B2B',
    title: 'Водитель на дальние дистанции',
    city: 'Кобе, Япония',
    company: 'CocaCola',
    logo: cocacola,
    date: '1 день назад',
  },
];

export default function VacancyList() {
  return (
    <section className={styles.section}>
      <div className={styles.inner}>
        <h2 className={styles.title}>Новые вакансии</h2>
        <p className={styles.subtitle}>Найди работу своей мечты прямо сейчас</p>
        <div className={styles.list}>
          {vacancies.map((v) => (
            <VacancyCard key={v.id} vacancy={v} />
          ))}
        </div>
        <a href="#" className={styles.all_button}>Все вакансии</a>
      </div>
    </section>
  );
}
