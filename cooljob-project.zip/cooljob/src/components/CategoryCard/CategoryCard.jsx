import styles from './CategoryCard.module.css';

export default function CategoryCard({ cardInfo, more = false }) {
  return (
    <a href="#" className={more ? `${styles.card} ${styles.more}` : styles.card}>
      <img src={cardInfo.url} alt="" className={styles.card_icon} />
      <span className={styles.card_text}>{cardInfo.text}</span>
    </a>
  );
}
