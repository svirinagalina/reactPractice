import disney from '../../assets/logos/disney.png';
import facebook from '../../assets/logos/facebook.png';
import microsoft from '../../assets/logos/microsoft.png';
import sony from '../../assets/logos/sony.png';
import cocacola from '../../assets/logos/cocacola.png';
import styles from './PartnersBar.module.css';

const partners = [
  { name: 'Disney', logo: disney },
  { name: 'Facebook', logo: facebook },
  { name: 'Microsoft', logo: microsoft },
  { name: 'Sony', logo: sony },
  { name: 'Coca-Cola', logo: cocacola },
];

export default function PartnersBar() {
  return (
    <section className={styles.companies}>
      <p className={styles.companies_title}>Помогаем найти работу:</p>
      <ul className={styles.companies_logos}>
        {partners.map((p) => (
          <li key={p.name}>
            <img src={p.logo} alt={p.name} className={styles.logo} />
          </li>
        ))}
      </ul>
    </section>
  );
}
