import iconSearch from '../../assets/icons/icon_search.svg';
import iconLocation from '../../assets/icons/icon_location.svg';
import heroShape from '../../assets/images/hero_shape.svg';
import styles from './SearchBar.module.css';

export default function SearchBar() {
  return (
    <section className={styles.search_div}>
      <img src={heroShape} alt="" className={styles.hero_shape} />
      <div className={styles.content}>
        <h1 className={styles.search_title}>
          Один клик <br /> и работа в кармане
        </h1>
        <form className={styles.form} onSubmit={(e) => e.preventDefault()}>
          <label className={styles.first_input_wrap}>
            <img src={iconSearch} alt="" className={styles.input_icon} />
            <input
              type="text"
              name="query"
              placeholder="Должность или компания"
              className={styles.input}
            />
          </label>
          <span className={styles.divider} aria-hidden="true" />
          <label className={styles.second_input_wrap}>
            <img src={iconLocation} alt="" className={styles.input_icon} />
            <input
              type="text"
              name="city"
              placeholder="Город, Страна"
              className={styles.input}
            />
          </label>
          <button type="submit" className={styles.form_button}>
            Поиск
          </button>
        </form>
      </div>
    </section>
  );
}
