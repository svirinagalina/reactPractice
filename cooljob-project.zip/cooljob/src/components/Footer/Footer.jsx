import linkedin from '../../assets/social/linkedin.svg';
import google from '../../assets/social/google.svg';
import twitter from '../../assets/social/twitter.svg';
import facebook from '../../assets/social/facebook.svg';
import styles from './Footer.module.css';

const cities = [
  'Осака', 'Коясан', 'Токио', 'Хаконэ', 'Наэба',
  'Томаму', 'Йокогама', 'Нагоя', 'Саппоро', 'Кобе',
];

const socials = [
  { name: 'LinkedIn', icon: linkedin },
  { name: 'Google', icon: google },
  { name: 'Twitter', icon: twitter },
  { name: 'Facebook', icon: facebook },
];

export default function Footer() {
  return (
    <footer className={styles.footer}>
      <div className={styles.inner}>
        <h2 className={styles.title}>Популярные города</h2>
        <ul className={styles.cities}>
          {cities.map((city) => (
            <li key={city}>
              <a href="#" className={styles.city}>{city}</a>
            </li>
          ))}
        </ul>
        <div className={styles.bottom}>
          <a href="/" className={styles.logo}>Cooljob</a>
          <ul className={styles.socials}>
            {socials.map((s) => (
              <li key={s.name}>
                <a href="#" className={styles.social} aria-label={s.name}>
                  <img src={s.icon} alt="" />
                </a>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </footer>
  );
}
