import iconLocation from '../../assets/icons/icon_location.svg';
import styles from './VacancyCard.module.css';

export default function VacancyCard({ vacancy }) {
  return (
    <article className={styles.card}>
      <p className={styles.category}>
        <span className={styles.dot} style={{ background: vacancy.color }} />
        {vacancy.category}
      </p>
      <h3 className={styles.title}>
        <a href="#" className={styles.link}>{vacancy.title}</a>
      </h3>
      <p className={styles.city}>
        <img src={iconLocation} alt="" className={styles.city_icon} />
        {vacancy.city}
      </p>
      <p className={styles.company}>
        <img src={vacancy.logo} alt="" className={styles.company_logo} />
        {vacancy.company}, {vacancy.date}
      </p>
    </article>
  );
}
