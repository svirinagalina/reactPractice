import CategoryCard from '../CategoryCard/CategoryCard.jsx';
import iconFinance from '../../assets/icons/icon_finance.svg';
import iconTransport from '../../assets/icons/icon_transport.svg';
import iconDesign from '../../assets/icons/icon_design.svg';
import iconRestaurant from '../../assets/icons/icon_restaurant.svg';
import iconMedicine from '../../assets/icons/icon_medicine.svg';
import iconMultimedia from '../../assets/icons/icon_multimedia.svg';
import iconSupport from '../../assets/icons/icon_support.svg';
import iconManagement from '../../assets/icons/icon_management.svg';
import iconSales from '../../assets/icons/icon_sales.svg';
import iconArrow from '../../assets/icons/icon_arrow.svg';
import styles from './CategoryCardList.module.css';

const cardInfo = [
  { url: iconFinance, text: 'Финансы' },
  { url: iconTransport, text: 'Грузоперевозки' },
  { url: iconDesign, text: 'Дизайн' },
  { url: iconRestaurant, text: 'Ресторанный бизнес' },
  { url: iconMedicine, text: 'Медицина' },
  { url: iconMultimedia, text: 'Мультимедиа' },
  { url: iconSupport, text: 'Служба поддержки' },
  { url: iconManagement, text: 'Менеджмент' },
  { url: iconSales, text: 'Продажи' },
];

export default function CategoryCardList() {
  return (
    <section className={styles.section}>
      <h2 className={styles.title}>
        Работа <br /> по категориям
      </h2>
      <div className={styles.card_list}>
        {cardInfo.map((card) => (
          <CategoryCard key={card.text} cardInfo={card} />
        ))}
        <CategoryCard cardInfo={{ url: iconArrow, text: 'Больше категорий' }} more />
      </div>
    </section>
  );
}
