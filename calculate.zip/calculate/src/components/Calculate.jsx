import React, {useState} from 'react'

function Calculate() {
    const [count, setCount] = useState(0);
    const increaseValue = () => {
        setCount(prevCount => prevCount + 1);
    }
    const decreaseValue = () => {
        setCount(prevCount => prevCount - 1);
    }
    const zeroValue = () => {
        setCount(prevCount => 0);
    }

    return (
        <div className="Calculate">
        <h1>Текущий счет: {count}</h1>
        <button onClick={zeroValue}> Обнулить</button>
            <button onClick={increaseValue}> Увеличить </button>
            <button onClick={decreaseValue}> Уменьшить </button>
        </div>
    );
}
export default Calculate;
